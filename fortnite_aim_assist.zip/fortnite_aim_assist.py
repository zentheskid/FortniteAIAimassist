import random

class FortniteAIAimAssist:
    """
    Class to simulate an AI aim assist for Fortnite game.

    Attributes:
    - sensitivity: float
        The sensitivity of the aim assist. Higher values mean faster tracking.
    - target_distance: float
        The distance to the target. Higher values mean the target is farther away.
    """

    def __init__(self, sensitivity: float, target_distance: float):
        """
        Constructor to instantiate the FortniteAIAimAssist class.

        Parameters:
        - sensitivity: float
            The sensitivity of the aim assist. Should be a positive value.
        - target_distance: float
            The distance to the target. Should be a positive value.
        """

        # Verifying that sensitivity and target_distance are positive values.
        if sensitivity <= 0 or target_distance <= 0:
            raise ValueError("Sensitivity and target distance should be positive values.")

        # Assigning the sensitivity and target_distance to the instance variables.
        self.sensitivity = sensitivity
        self.target_distance = target_distance

    def calculate_aim_offset(self):
        """
        Calculates the aim offset based on the sensitivity and target distance.

        Returns:
        - float:
            The calculated aim offset.
        """

        # Calculating the aim offset using the formula: sensitivity * target_distance
        aim_offset = self.sensitivity * self.target_distance

        return aim_offset

    def simulate_aim_assist(self):
        """
        Simulates the aim assist by randomly generating a deviation from the target position.

        Returns:
        - float:
            The simulated aim assist deviation.
        """

        # Calculating the aim offset using the calculate_aim_offset method
        aim_offset = self.calculate_aim_offset()

        # Generating a random deviation within the aim offset range
        aim_deviation = random.uniform(-aim_offset, aim_offset)

        return aim_deviation

# Example of using the FortniteAIAimAssist class:
if __name__ == "__main__":
    # Example: Simulating aim assist for a sensitivity of 2.5 and target distance of 10.0
    aim_assist = FortniteAIAimAssist(2.5, 10.0)
    aim_deviation = aim_assist.simulate_aim_assist()
    print(f"The aim deviation for sensitivity {aim_assist.sensitivity} and target distance {aim_assist.target_distance} is {aim_deviation}.")
